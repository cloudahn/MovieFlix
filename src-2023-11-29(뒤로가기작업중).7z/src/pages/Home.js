import React, {useEffect} from 'react'
import { movieAction } from '../redux/actions/movieAction'
import { useDispatch, useSelector } from 'react-redux'
import Banner from '../components/Banner'
import MovieSlide from '../components/MovieSlide'
import ClipLoader from "react-spinners/ClipLoader";

const Home = () => {
  const dispatch = useDispatch()
  const {popularMovies,topRatedMovies,upComingMovies,loading} = useSelector((state)=>state.movie)
  const obj = {
    mode : "main",
    page : 1,
    search : ""
  }
  useEffect(() => {
    dispatch(movieAction.getMovies(obj))
  },[])

//loading ==  true : 데이터가 오기 전
//loading == false : 데이터 온 후 또는 에러 발생

if (loading) {
  return <ClipLoader
  color="#ffff"
  loading={loading}
  size={150}
/>
}

  return (
    <div>
      <Banner movie={popularMovies.results[0]} />
      <h5>Popular Movie</h5>
      <MovieSlide movies={popularMovies} />
      <h5>Top rated Movie</h5>
      <MovieSlide movies={topRatedMovies}/>
      <h5>Upcoming Movie</h5>
      <MovieSlide movies={upComingMovies}/>
    </div>
  )
}

export default Home
