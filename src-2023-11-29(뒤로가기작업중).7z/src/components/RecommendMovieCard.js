import React from 'react'
import { Badge } from 'react-bootstrap'
import { useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'

const RecommendMovieCard = ({item}) => {

  const navigate = useNavigate() 
  const {genreList} = useSelector(state=>state.movie)

  const showMovieDetail=()=>{
    navigate(`/movies/${item.id}`,{state:{item}})
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div className="card_recommend" style={{backgroundImage:"url("+`https://www.themoviedb.org/t/p/w500_and_h282_face/${item.backdrop_path}`+")"}} onClick={showMovieDetail}>
       <div className='overlay'>
          <h5>{item.title}</h5>
          <div>{item.genre_ids.map((id)=> (
              <Badge bg="success" className='movie-genre-badge'>{genreList.find((item) => item.id == id).name}</Badge>
            ))}</div>
          <div>
            <span>{item.vote_average}</span>
            <span>{item.adult?"청불":"Under 18"}</span>
          </div>
        </div>
    </div>
  )
}

export default RecommendMovieCard
