import React from 'react'

const Button = () => {
  return (
    <div>
      button place
    </div>
  )
}

export default Button
